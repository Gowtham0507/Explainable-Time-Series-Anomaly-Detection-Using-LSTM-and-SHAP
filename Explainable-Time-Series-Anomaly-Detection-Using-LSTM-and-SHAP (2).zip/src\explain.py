import argparse
import os
import torch
import numpy as np
import shap
import json
import logging
from data_loader import get_dataloaders
from model import LSTMAutoencoder

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load Config
    with open(os.path.join(args.model_dir, 'config.json'), 'r') as f:
        config = json.load(f)
        
    # Load Data
    train_loader, _, test_loader, _, test_y = get_dataloaders(
        config['data_path'], 
        dataset=config['dataset'],
        batch_size=config['batch_size'], 
        seq_len=config['seq_len'],
        seed=config['seed']
    )
    
    # Load LSTM Model
    input_dim = next(iter(train_loader))[0].shape[2]
    model = LSTMAutoencoder(input_dim=input_dim, hidden_dim=config['hidden_dim'], num_layers=config['num_layers'])
    model.load_state_dict(torch.load(os.path.join(args.model_dir, 'best_model.pth')))
    model.to(device)
    model.eval()
    
    # Select Background Data for SHAP (Normal data from Train)
    # Use a small random sample
    background_batch = next(iter(train_loader))[0]
    background_batch = background_batch[:100].to(device)
    
    # Initialize Explainer
    # Use GradientExplainer or DeepExplainer
    logger.info("Initializing SHAP Explainer...")
    try:
        explainer = shap.DeepExplainer(model, background_batch)
    except Exception as e:
        logger.warning(f"DeepExplainer failed: {e}. Falling back to GradientExplainer.")
        explainer = shap.GradientExplainer(model, background_batch)
        
    # Load Test Scores to find top-k anomalies
    scores_path = os.path.join(args.model_dir, 'test_scores_lstm.npy')
    if not os.path.exists(scores_path):
        logger.error("Test scores not found. Run evaluate.py first.")
        return
        
    scores = np.load(scores_path)
    
    # Find Top-K Anomalies
    # Sort indices by score descending
    top_k_indices = np.argsort(scores)[-args.top_k:]
    
    logger.info(f"Computing SHAP values for top {args.top_k} anomalies...")
    
    # We need the actual data for these indices.
    # The test_loader is sequential, so we can index into the dataset.
    # However, DataLoader might not be indexable easily if shuffle=True (Test is False).
    # We can retrieve the full test tensor from the dataset.
    
    test_dataset = test_loader.dataset
    # Access underlying sequences
    # Assuming test_dataset has .sequences attribute (our SMAPMSLDataset class)
    # Wait, in data_loader.py: SMAPMSLDataset stores sequences in self.sequences (which isn't tensor yet?).
    # let's check class definition
    
    # class SMAPMSLDataset(Dataset):
    #     def __init__(self, sequences, labels=None):
    #         self.sequences = sequences
    
    # Yes.
    
    # Get the windows for top indices
    target_windows = []
    for idx in top_k_indices:
        target_windows.append(test_dataset[idx][0]) # [0] is seq, [1] is label
        
    target_tensor = torch.stack(target_windows).to(device)
    
    # Compute SHAP
    shap_values = explainer.shap_values(target_tensor)
    
    # shap_values format for DeepExplainer on PyTorch: list of arrays (one for each output)?
    # For AE, output is same shape as input.
    # shap_values is typically a list for multi-output models.
    # We will verify shape.
    
    # Save SHAP values
    save_path = os.path.join(args.model_dir, 'shap_values_top_k.npy')
    # If it's a list, save as object or array?
    # Usually list of numpy arrays.
    
    # Let's save a dictionary with indices and values
    shap_data = {
        "indices": top_k_indices.tolist(),
        "shap_values": np.array(shap_values) if not isinstance(shap_values, list) else [arr.tolist() for arr in shap_values],
        "input_data": target_tensor.cpu().numpy().tolist()
    }
    
    # Using pickle for complex structure or npy for arrays
    # JSON for safety if list
    with open(os.path.join(args.model_dir, 'shap_analysis.json'), 'w') as f:
        json.dump(shap_data, f)
        
    logger.info(f"SHAP analysis saved to {save_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_dir', type=str, default='d:/LSTM/time_series_anomaly_detection/data/processed')
    parser.add_argument('--top_k', type=int, default=5)
    args = parser.parse_args()
    
    main(args)
