import torch
import torch.nn as nn
import numpy as np

class LSTMAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_layers=1, dropout=0.0):
        super(LSTMAutoencoder, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        
        # Encoder
        self.encoder = nn.LSTM(
            input_size=input_dim, 
            hidden_size=hidden_dim, 
            num_layers=num_layers, 
            batch_first=True,
            dropout=dropout
        )
        
        # Decoder
        # We decode from hidden representation to recreate the sequence
        self.decoder = nn.LSTM(
            input_size=hidden_dim, 
            hidden_size=hidden_dim, 
            num_layers=num_layers, 
            batch_first=True,
            dropout=dropout
        )
        
        self.output_layer = nn.Linear(hidden_dim, input_dim)
        
    def forward(self, x):
        # x: (batch_size, seq_len, input_dim)
        
        # Encoder
        # enc_out: (batch, seq, hidden), (h_n, c_n)
        _, (h_n, c_n) = self.encoder(x)
        
        # Use the last hidden state to initialize decoder or repeat it?
        # Standard AE: Repeat vector. 
        # Here we can use the encoder structure to return a sequence.
        # Let's try to reconstruct the sequence using the hidden states.
        
        # We want to reconstruct x.
        # Decoder input: We can feed zeros or the encoded state repeated.
        # Better strategy for TS: "Predictive Autoencoder" or just reconstruction.
        # We will iterate:
        # Decoder input 0: h_n repeated? 
        # Let's use a simpler approach: 
        # Encoder projects to latent (h_n).
        # Decoder reconstructs from latent reversed or repeated.
        
        # Repeat h_n for each timestep
        # h_n shape: (num_layers, batch, hidden). We take last layer: (batch, hidden)
        last_hidden = h_n[-1]
        
        # Repeat for seq_len
        # (batch, seq_len, hidden)
        decoder_input = last_hidden.unsqueeze(1).repeat(1, x.size(1), 1)
        
        # Decode
        dec_out, _ = self.decoder(decoder_input) # (batch, seq, hidden)
        
        # Map to output
        reconstruction = self.output_layer(dec_out)
        
        return reconstruction

class EWMABaseline:
    def __init__(self, alpha=0.3):
        self.alpha = alpha
        self.mean = None
        self.std = None
        
    def fit(self, X):
        # X: (N, seq_len, features) or (N*seq, features)
        # We compute statistics of the errors or just data stats?
        # EWMA is usually "predict next given history". 
        # For baseline, we can just process the stream.
        # We don't really 'train' EWMA parameters other than maybe alpha (which we fix).
        pass
        
    def predict(self, X):
        # X: (batch, seq_len, features)
        # We calculate EWMA for each sequence independently?
        # Or better: X is a batch of windows.
        # We predict the last value in the window using EWMA of the window.
        # Prediction for t: \hat{x}_t = alpha * x_t + (1-alpha) * \hat{x}_{t-1}
        # But this is smoothing.
        # Anomaly detection: Error = |x_t - \hat{x}_{t-1}| (One step ahead prediction)
        
        # Let's compute EWMA for each feature in the window
        # Return error matrix: (batch, seq_len, features)
        
        preds = []
        # Vectorized implementation might be hard for pure EWMA per window if windows are independent.
        # Assuming X is sliding windows.
        
        # Simple loop for clarity and baseline correctness (it's fast enough for this scale)
        # Actually, pandas has ewm.
        # But we have tensor/numpy array.
        
        B, T, F = X.shape
        predictions = np.zeros_like(X)
        
        # Intialize with first value
        predictions[:, 0, :] = X[:, 0, :]
        
        for t in range(1, T):
            predictions[:, t, :] = self.alpha * X[:, t-1, :] + (1 - self.alpha) * predictions[:, t-1, :]
            
        return predictions

