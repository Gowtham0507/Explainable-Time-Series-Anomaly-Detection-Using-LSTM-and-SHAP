import os
import numpy as np
import pandas as pd

data_path = "d:/LSTM/time_series_anomaly_detection/data/raw/train"
files = [f for f in os.listdir(data_path) if f.endswith('.npy')]
print(f"Found {len(files)} files in {data_path}")

shapes = {}
for count, f in enumerate(files):
    path = os.path.join(data_path, f)
    try:
        data = np.load(path)
        shapes[f] = data.shape
        print(f"{f}: {data.shape}")
    except Exception as e:
        print(f"Error reading {f}: {e}")
    if count >= 10: break

# Check consistency
feature_counts = [s[1] if len(s) > 1 else 1 for s in shapes.values()]
print(f"Unique feature counts found in first 10: {set(feature_counts)}")
