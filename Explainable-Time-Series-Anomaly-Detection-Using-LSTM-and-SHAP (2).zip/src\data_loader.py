import os
import ast
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SMAPMSLDataset(Dataset):
    def __init__(self, sequences, labels=None):
        self.sequences = sequences
        self.labels = labels

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        seq = torch.tensor(self.sequences[idx], dtype=torch.float32)
        if self.labels is not None:
            label = torch.tensor(self.labels[idx], dtype=torch.float32)
            return seq, label
        return seq, torch.zeros(1) # Dummy label for train if needed

class AnomalyDataLoader:
    def __init__(self, data_path, seq_len=100, horizon=1, stride=1, seed=42):
        self.data_path = data_path
        self.seq_len = seq_len
        self.horizon = horizon # Size of target (1 for prediction/reconstruction)
        self.stride = stride
        self.seed = seed
        self.train_path = os.path.join(data_path, 'train')
        self.test_path = os.path.join(data_path, 'test')
        self.label_file = os.path.join(data_path, 'labeled_anomalies.csv')
        
        # Load anomaly labels
        self.anomalies = pd.read_csv(self.label_file)
        
    def load_data(self, dataset_name='SMAP'):
        """
        Load and process data for a specific dataset (SMAP or MSL).
        Returns dataloaders for train, val, test.
        """
        # Filter by dataset
        subset = self.anomalies[self.anomalies['spacecraft'] == dataset_name]
        
        all_train_seqs = []
        all_val_seqs = []
        all_test_seqs = []
        all_val_labels = []
        all_test_labels = []
        
        logger.info(f"Loading {dataset_name} dataset with {len(subset)} channels...")
        
        for _, row in subset.iterrows():
            chan_id = row['chan_id']
            
            # Load Train Data (Normal)
            try:
                train_npy = os.path.join(self.train_path, f"{chan_id}.npy")
                test_npy = os.path.join(self.test_path, f"{chan_id}.npy")
                
                if not os.path.exists(train_npy) or not os.path.exists(test_npy):
                    logger.warning(f"Files not found for {chan_id}, skipping.")
                    continue
                    
                train_data = np.load(train_npy)
                test_data = np.load(test_npy)
            except Exception as e:
                logger.error(f"Error loading {chan_id}: {e}")
                continue

            # Normalize based on Train data
            scaler = MinMaxScaler()
            train_data = scaler.fit_transform(train_data)
            test_data = scaler.transform(test_data)
            
            # Create sliding windows for Train
            train_windows = self._create_windows(train_data)
            all_train_seqs.append(train_windows)
            
            # Process Test Data & Labels
            # Parse anomalies
            anomaly_intervals = ast.literal_eval(row['anomaly_sequences'])
            
            # Create binary label mask (1=Anomaly, 0=Normal)
            y_test = np.zeros(len(test_data))
            for start, end in anomaly_intervals:
                # Ensure indices are within bounds
                start = max(0, start)
                end = min(len(y_test), end)
                y_test[start:end] = 1
            
            # Split Test Data into Validation and Test (50/50 split of the timeline)
            # We want validation to verify threshold, so it needs anomalies.
            split_idx = len(test_data) // 2
            
            val_data = test_data[:split_idx]
            val_y = y_test[:split_idx]
            
            test_final_data = test_data[split_idx:]
            test_final_y = y_test[split_idx:]
            
            # Create windows for Val and Test
            # Note: Features and Labels must be windowed
            # For reconstruction: Input=Window, Label=Window (or just label for the last point?)
            # Usually for Anomaly Detection: Label corresponds to the LAST point in the window or the WHOLE window
            # Task Requirement: "Convert anomaly ranges into a binary anomaly label per timestep"
            # We will assign label to the last timestep of the window for simplicity in evaluation
            
            val_windows, val_win_labels = self._create_windows(val_data, labels=val_y)
            test_windows, test_win_labels = self._create_windows(test_final_data, labels=test_final_y)
            
            all_val_seqs.append(val_windows)
            all_test_seqs.append(test_windows)
            all_val_labels.append(val_win_labels)
            all_test_labels.append(test_win_labels)

        # Concatenate all channels
        # Note: This mixes channels. For 'per-channel' training we would not concat. 
        # But for 'Grouped' (Project requirement implies we can do either, but "Aggregated across channels" sugggests one model or aggregate metrics).
        # We will implement 'Aggregated' mode: One global model for SMAP, one for MSL (or one for all).
        # Given "Train per channel OR grouped channels", and "scalability", we will do Grouped by default for simplicity of the pipeline, 
        # as training 50+ models is slow.
        
        train_X = np.concatenate(all_train_seqs, axis=0) if all_train_seqs else np.array([])
        val_X = np.concatenate(all_val_seqs, axis=0) if all_val_seqs else np.array([])
        test_X = np.concatenate(all_test_seqs, axis=0) if all_test_seqs else np.array([])
        
        val_y = np.concatenate(all_val_labels, axis=0) if all_val_labels else np.array([])
        test_y = np.concatenate(all_test_labels, axis=0) if all_test_labels else np.array([])
        
        logger.info(f"Train Shape: {train_X.shape}")
        logger.info(f"Val Shape: {val_X.shape}")
        logger.info(f"Test Shape: {test_X.shape}")
        
        return train_X, val_X, val_y, test_X, test_y

    def load_channel(self, chan_id, dataset_name='SMAP'):
        """
        Load data for a single channel.
        """
        train_npy = os.path.join(self.train_path, f"{chan_id}.npy")
        test_npy = os.path.join(self.test_path, f"{chan_id}.npy")
        
        if not os.path.exists(train_npy) or not os.path.exists(test_npy):
            raise FileNotFoundError(f"Channel {chan_id} not found.")
            
        train_data = np.load(train_npy)
        test_data = np.load(test_npy)
        
        # Normalize
        scaler = MinMaxScaler()
        train_data = scaler.fit_transform(train_data)
        test_data = scaler.transform(test_data)
        
        # Windows
        # For dashboard, we might want the full sequence + anomaly overlay, 
        # but the model expects windows.
        # We will return the raw normalized data for plotting, and windows for inference.
        
        # Get labels
        row = self.anomalies[self.anomalies['chan_id'] == chan_id].iloc[0]
        anomaly_intervals = ast.literal_eval(row['anomaly_sequences'])
        y_test = np.zeros(len(test_data))
        for start, end in anomaly_intervals:
             start = max(0, start)
             end = min(len(y_test), end)
             y_test[start:end] = 1
             
        # Split (Same as global)
        split_idx = len(test_data) // 2
        # We return the Test portion primarily for visualization as that is where prediction happens
        # Use second half
        test_final_data = test_data[split_idx:]
        test_final_y = y_test[split_idx:]
        
        # Windows
        test_windows, test_win_labels = self._create_windows(test_final_data, labels=test_final_y)
        
        return test_final_data, test_final_y, test_windows, test_win_labels

    def _create_windows(self, data, labels=None):
        X = []
        y = []
        # Sliding window
        # data shape: (T, features)
        for i in range(len(data) - self.seq_len):
            X.append(data[i : i + self.seq_len])
            if labels is not None:
                # Label for the window is the label of the LAST timestamp
                y.append(labels[i + self.seq_len - 1])
                
        return np.array(X), np.array(y) if labels is not None else None

def get_dataloaders(data_path, dataset='SMAP', batch_size=64, seq_len=100, seed=42):
    # Set seeds
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    loader = AnomalyDataLoader(data_path, seq_len=seq_len, seed=seed)
    train_X, val_X, val_y, test_X, test_y = loader.load_data(dataset_name=dataset)
    
    train_dataset = SMAPMSLDataset(train_X)
    val_dataset = SMAPMSLDataset(val_X, val_y)
    test_dataset = SMAPMSLDataset(test_X, test_y)
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    return train_loader, val_loader, test_loader, val_y, test_y 

if __name__ == "__main__":
    # Test the loader
    path = "d:/LSTM/time_series_anomaly_detection/data/raw"
    t, v, te, vy, ty = get_dataloaders(path, dataset='SMAP', batch_size=32)
    print("Train batches:", len(t))
