import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import torch
import torch.nn as nn
import os
import json
import shap
from src.data_loader import AnomalyDataLoader
from src.model import LSTMAutoencoder, EWMABaseline

# Set Config
st.set_page_config(layout="wide", page_title="Anomaly Detection Dashboard")

BASE_DIR = "d:/LSTM/time_series_anomaly_detection"
DATA_DIR = os.path.join(BASE_DIR, "data/raw")
PROCESSED_DIR = os.path.join(BASE_DIR, "data/processed")

@st.cache_resource
def load_model(config):
    model = LSTMAutoencoder(input_dim=config['input_dim'], hidden_dim=config['hidden_dim'], num_layers=config['num_layers'])
    model.load_state_dict(torch.load(os.path.join(PROCESSED_DIR, 'best_model.pth'), map_location=torch.device('cpu')))
    model.eval()
    return model

@st.cache_data
def load_global_metrics():
    path = os.path.join(PROCESSED_DIR, 'evaluation_results.json')
    if os.path.exists(path):
        with open(path, 'r') as f:
            return json.load(f)
    return None

def compute_anomaly_score(model, windows):
    with torch.no_grad():
        x = torch.tensor(windows, dtype=torch.float32)
        recon = model(x)
        error = torch.mean((recon - x) ** 2, dim=[1, 2])
    return error.numpy()

def main():
    st.title("🛰️ Spacecraft Anomaly Detection System")
    st.markdown("### LSTM Autoencoder vs EWMA Baseline | Explainable AI")
    
    # Sidebar
    st.sidebar.header("Configuration")
    # dataset_name = st.sidebar.selectbox("Dataset", ["SMAP", "MSL"])
    dataset_name = "SMAP" # Only SMAP trained
    st.sidebar.markdown(f"**Dataset:** {dataset_name}")
    
    # Load Data Loader
    loader = AnomalyDataLoader(DATA_DIR, seq_len=100)
    
    # Get Channels for Dataset
    subset = loader.anomalies[loader.anomalies['spacecraft'] == dataset_name]
    channels = subset['chan_id'].unique().tolist()
    
    selected_channel = st.sidebar.selectbox("Select Channel", channels)
    
    # Global Metrics
    metrics = load_global_metrics()
    if metrics:
        st.sidebar.markdown("---")
        st.sidebar.subheader("Global Performance (Test Set)")
        col1, col2 = st.sidebar.columns(2)
        col1.metric("LSTM F1", f"{metrics['lstm']['metrics']['f1']:.3f}")
        col2.metric("Baseline F1", f"{metrics['baseline']['metrics']['f1']:.3f}")
        
    # Main Content - localized loading
    if selected_channel:
        try:
            # Load Channel Data
            data_raw, labels_raw, windows, window_labels = loader.load_channel(selected_channel, dataset_name)
            
            # Load Model and Config (Per-Channel)
            config_path = os.path.join(PROCESSED_DIR, f'config_{selected_channel}.json')
            model_path = os.path.join(PROCESSED_DIR, f'model_{selected_channel}.pth')
            
            if not os.path.exists(config_path) or not os.path.exists(model_path):
                st.error(f"Model for channel {selected_channel} not found. Please train first.")
                return
                
            with open(config_path, 'r') as f:
                config = json.load(f)
            
            # Load Model
            # Note: load_model is cached. We need to cache based on channel ID or ensure cache invalidates?
            # Streamlit cache argument hashing works.
            # But the 'config' dict is passed.
            # Wait, load_model hardcodes path 'best_model.pth'. We need to pass path.
            
            @st.cache_resource
            def load_channel_model(path, input_dim, hidden_dim, num_layers):
                model = LSTMAutoencoder(input_dim=input_dim, hidden_dim=hidden_dim, num_layers=num_layers)
                model.load_state_dict(torch.load(path, map_location=torch.device('cpu')))
                model.eval()
                return model

            model = load_channel_model(model_path, config['input_dim'], config['hidden_dim'], config['num_layers'])
            
            # 1. Run LSTM
            lstm_scores = compute_anomaly_score(model, windows)
            # Threshold from global config or tuned? 
            # We use global threshold found in evaluation
            lstm_thresh = metrics['lstm']['threshold'] if metrics else np.mean(lstm_scores) + 3*np.std(lstm_scores)
            lstm_preds = (lstm_scores > lstm_thresh).astype(int)
            
            # 2. Run Baseline
            baseline = EWMABaseline(alpha=0.3)
            # Predict on windows (approximate for baseline usage in this context)
            baseline_preds_vals = baseline.predict(windows) 
            base_scores = np.mean((windows - baseline_preds_vals) ** 2, axis=(1, 2))
            base_thresh = metrics['baseline']['threshold'] if metrics else np.mean(base_scores) + 3*np.std(base_scores)
            
            # Layout
            tab1, tab2, tab3 = st.tabs(["Signal & Anomalies", "Model Comparison", "Explainability"])
            
            with tab1:
                st.subheader(f"Channel {selected_channel} - Signal View")
                # Plot Raw Data (First dimension usually if multivariate)
                fig_raw = go.Figure()
                # Plot first feature
                fig_raw.add_trace(go.Scatter(y=data_raw[:, 0], mode='lines', name='Signal (Feat 0)', line=dict(color='blue', width=1)))
                
                # Highlight True Anomalies
                anomaly_indices = np.where(labels_raw == 1)[0]
                # We can add shapes or scatter points
                fig_raw.add_trace(go.Scatter(x=anomaly_indices, y=data_raw[anomaly_indices, 0], mode='markers', name='True Anomaly', marker=dict(color='red', size=5)))
                
                st.plotly_chart(fig_raw, use_container_width=True)
                
            with tab2:
                st.subheader("LSTM vs Baseline Performance")
                
                col_a, col_b = st.columns(2)
                
                with col_a:
                    st.markdown("**LSTM Autoencoder**")
                    fig_lstm = go.Figure()
                    fig_lstm.add_trace(go.Scatter(y=lstm_scores, mode='lines', name='Anomaly Score', line=dict(color='orange')))
                    fig_lstm.add_hline(y=lstm_thresh, line_dash="dash", line_color="red", annotation_text="Threshold")
                    st.plotly_chart(fig_lstm, use_container_width=True)
                    
                    # Metrics for this channel
                    tp = np.sum((lstm_preds == 1) & (window_labels == 1))
                    fp = np.sum((lstm_preds == 1) & (window_labels == 0))
                    fn = np.sum((lstm_preds == 0) & (window_labels == 1))
                    precision = tp / (tp + fp) if (tp+fp) > 0 else 0
                    recall = tp / (tp + fn) if (tp+fn) > 0 else 0
                    f1 = 2*precision*recall/(precision+recall) if (precision+recall) > 0 else 0
                    st.caption(f"Channel F1: {f1:.3f}")
                    
                with col_b:
                    st.markdown("**EWMA Baseline**")
                    fig_base = go.Figure()
                    fig_base.add_trace(go.Scatter(y=base_scores, mode='lines', name='Anomaly Score', line=dict(color='green')))
                    fig_base.add_hline(y=base_thresh, line_dash="dash", line_color="red", annotation_text="Threshold")
                    st.plotly_chart(fig_base, use_container_width=True)
                    
                    tp = np.sum((base_scores > base_thresh) & (window_labels == 1))
                    fp = np.sum((base_scores > base_thresh) & (window_labels == 0))
                    fn = np.sum((base_scores <= base_thresh) & (window_labels == 1))
                    precision = tp / (tp + fp) if (tp+fp) > 0 else 0
                    recall = tp / (tp + fn) if (tp+fn) > 0 else 0
                    f1 = 2*precision*recall/(precision+recall) if (precision+recall) > 0 else 0
                    st.caption(f"Channel F1: {f1:.3f}")

            with tab3:
                st.subheader("Explainability (SHAP)")
                
                if st.button("Explain Top Anomalies in this Channel"):
                    with st.spinner("Computing SHAP values..."):
                        # Select Top Anomaly in this channel
                        top_idx = np.argmax(lstm_scores)
                        target_window = windows[top_idx] # (seq, feat)
                        
                        # Background for SHAP
                        background = windows[:50] 
                        
                        # Wrapper to explain MSE Loss
                        class MSELossModel(nn.Module):
                            def __init__(self, model):
                                super().__init__()
                                self.model = model
                            
                            def forward(self, x):
                                recon = self.model(x)
                                # MSE per sample
                                loss = torch.mean((recon - x) ** 2, dim=[1, 2])
                                return loss.unsqueeze(1) # (batch, 1) Output for SHAP
                        
                        wrapped_model = MSELossModel(model)
                        
                        explainer = shap.GradientExplainer(wrapped_model, torch.tensor(background, dtype=torch.float32))
                        
                        shap_values = explainer.shap_values(torch.tensor(target_window, dtype=torch.float32).unsqueeze(0))
                        
                        # shap_values from GradientExplainer for one output is a list [arrays]
                        # Since we have 1 output (Loss), it is a list of length 1.
                        # The array inside is (batch, seq, feat)
                        
                        explanation = np.array(shap_values[0]) # (1, seq, feat)
                        shap_matrix = explanation[0] # (seq, feat)
                        
                        st.markdown("**Feature Contribution to Anomaly Score (MSE Loss)**")
                        
                        fig_shap = go.Figure(data=go.Heatmap(
                            z=shap_matrix.T,
                            x=np.arange(shap_matrix.shape[0]),
                            y=[f"Feat {i}" for i in range(shap_matrix.shape[1])],
                            colorscale='RdBu'
                        ))
                        fig_shap.update_layout(title="SHAP Values (Red triggers Anomaly)", xaxis_title="Time Step", yaxis_title="Input Feature")
                        st.plotly_chart(fig_shap, use_container_width=True)

        except Exception as e:
            st.error(f"Error loading channel: {e}")

if __name__ == "__main__":
    main()
