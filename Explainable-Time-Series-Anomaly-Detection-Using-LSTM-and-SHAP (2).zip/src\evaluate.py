import argparse
import os
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import json
import logging
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score, confusion_matrix
from data_loader import AnomalyDataLoader
from model import LSTMAutoencoder, EWMABaseline

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def evaluate_channel(model, loader, chan_id, dataset, device, criterion):
    # Load Test Data for Channel
    try:
        # load_channel returns: test_final_data, test_final_y, test_windows, test_win_labels
        _, _, windows, labels = loader.load_channel(chan_id, dataset_name=dataset)
    except Exception as e:
        logger.warning(f"Could not load data for {chan_id}: {e}")
        return None, None

    if len(windows) == 0:
        return None, None
        
    model.eval()
    
    # Batch processing manually or wrap in loader
    # For Eval, just processing in chunks is fine or full validation
    batch_size = 64
    scores = []
    
    with torch.no_grad():
        for i in range(0, len(windows), batch_size):
            batch = windows[i:i+batch_size]
            x = torch.tensor(batch, dtype=torch.float32).to(device)
            recon = model(x)
            error = torch.mean((recon - x) ** 2, dim=[1, 2])
            scores.extend(error.cpu().numpy())
            
    return np.array(scores), labels

def evaluate_baseline_channel(baseline, loader, chan_id, dataset):
    try:
        _, _, windows, labels = loader.load_channel(chan_id, dataset_name=dataset)
    except:
        return None, None
        
    if len(windows) == 0:
        return None, None
        
    preds = baseline.predict(windows)
    scores = np.mean((windows - preds) ** 2, axis=(1, 2))
    return scores, labels

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    loader = AnomalyDataLoader(args.data_path, seq_len=100) # Seq len generic, should match config if possible
    # We will read seq_len from config per channel if needed, assuming 100 default
    
    subset = loader.anomalies[loader.anomalies['spacecraft'] == args.dataset]
    channels = subset['chan_id'].unique().tolist()
    
    # Aggregated results
    all_lstm_scores = []
    all_lstm_labels = []
    all_base_scores = []
    all_base_labels = []
    
    logger.info(f"Evaluating {len(channels)} channels...")
    
    for chan_id in channels:
        model_path = os.path.join(args.model_dir, f'model_{chan_id}.pth')
        config_path = os.path.join(args.model_dir, f'config_{chan_id}.json')
        
        if not os.path.exists(model_path) or not os.path.exists(config_path):
            continue
            
        with open(config_path, 'r') as f:
            config = json.load(f)
            
        # Load Model
        model = LSTMAutoencoder(input_dim=config['input_dim'], hidden_dim=config['hidden_dim'], num_layers=config['num_layers'])
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.to(device)
        
        scores, labels = evaluate_channel(model, loader, chan_id, args.dataset, device, nn.MSELoss(reduction='none'))
        if scores is not None:
             all_lstm_scores.append(scores)
             all_lstm_labels.append(labels)
             
        # Baseline
        base_scores, base_labels = evaluate_baseline_channel(EWMABaseline(), loader, chan_id, args.dataset)
        if base_scores is not None:
             all_base_scores.append(base_scores)
             all_base_labels.append(base_labels)
    
    if not all_lstm_scores:
        logger.error("No models evaluated.")
        return

    # Concatenate all for global thresholding
    # Note: Global thresholding assumes errors are on similar scales. 
    # With z-score normalization per channel, this is a reasonable assumption.
    # Alternatively: Find threshold per channel (Best F1) and aggregate?
    # Task says: "Select threshold using validation data".
    # Usually F1-best threshold on *aggregated* evaluation set is standard for competitions, 
    # or Per-Channel. Given the 'System' requirement, let's find one Best Global Threshold (or per channel).
    # Simple approach: Global Best F1
    
    global_lstm_scores = np.concatenate(all_lstm_scores)
    global_lstm_labels = np.concatenate(all_lstm_labels)
    global_base_scores = np.concatenate(all_base_scores)
    
    def find_best_f1(scores, labels):
        # Scan percentiles
        thresholds = np.percentile(scores, np.linspace(0, 100, 100))
        best_f1 = 0
        best_thresh = 0
        for t in thresholds:
            pred = (scores > t).astype(int)
            _, _, f1, _ = precision_recall_fscore_support(labels, pred, average='binary', zero_division=0)
            if f1 > best_f1:
                best_f1 = f1
                best_thresh = t
        return best_thresh, best_f1
        
    logger.info("Finding best LSTM Threshold...")
    lstm_thresh, lstm_f1 = find_best_f1(global_lstm_scores, global_lstm_labels)
    logger.info(f"LSTM Threshold: {lstm_thresh:.4f} - F1: {lstm_f1:.4f}")
    
    logger.info("Finding best Baseline Threshold...")
    base_thresh, base_f1 = find_best_f1(global_base_scores, global_lstm_labels) # Labels same
    logger.info(f"Baseline Threshold: {base_thresh:.4f} - F1: {base_f1:.4f}")
    
    # Calculate Final Metrics
    def calc_metrics(scores, labels, thresh):
        preds = (scores > thresh).astype(int)
        p, r, f, _ = precision_recall_fscore_support(labels, preds, average='binary', zero_division=0)
        auc = roc_auc_score(labels, scores)
        cm = confusion_matrix(labels, preds)
        return {"precision": p, "recall": r, "f1": f, "auc": auc, "confusion_matrix": cm.tolist()}
        
    lstm_metrics = calc_metrics(global_lstm_scores, global_lstm_labels, lstm_thresh)
    base_metrics = calc_metrics(global_base_scores, global_lstm_labels, base_thresh)
    
    # Save Results
    results = {
        "lstm": {"threshold": float(lstm_thresh), "metrics": lstm_metrics},
        "baseline": {"threshold": float(base_thresh), "metrics": base_metrics}
    }
    
    with open(os.path.join(args.model_dir, 'evaluation_results.json'), 'w') as f:
        json.dump(results, f, indent=4)
        
    # Print Report
    print("\n" + "="*50)
    print("GLOBAL EVALUATION RESULTS (Aggregated)")
    print("="*50)
    print(f"{'Metric':<15} {'LSTM':<15} {'Baseline':<15}")
    print("-" * 45)
    print(f"{'Precision':<15} {lstm_metrics['precision']:.4f}          {base_metrics['precision']:.4f}")
    print(f"{'Recall':<15} {lstm_metrics['recall']:.4f}          {base_metrics['recall']:.4f}")
    print(f"{'F1 Score':<15} {lstm_metrics['f1']:.4f}          {base_metrics['f1']:.4f}")
    print(f"{'ROC AUC':<15} {lstm_metrics['auc']:.4f}          {base_metrics['auc']:.4f}")
    print("="*50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='d:/LSTM/time_series_anomaly_detection/data/raw')
    parser.add_argument('--dataset', type=str, default='SMAP')
    parser.add_argument('--model_dir', type=str, default='d:/LSTM/time_series_anomaly_detection/data/processed')
    args = parser.parse_args()
    
    main(args)
