import os
import platform
import sys

print("Attempting to pre-load c10.dll...")

if platform.system() == "Windows":
    import ctypes
    from importlib.util import find_spec
    try:
        if (spec := find_spec("torch")) and spec.origin:
            print(f"Torch found at: {spec.origin}")
            dll_path = os.path.join(os.path.dirname(spec.origin), "lib", "c10.dll")
            if os.path.exists(dll_path):
                print(f"Loading DLL: {dll_path}")
                ctypes.CDLL(os.path.normpath(dll_path))
                print("DLL Loaded successfully.")
            else:
                print(f"DLL not found at {dll_path}")
    except Exception as e:
        print(f"Error loading DLL: {e}")

try:
    import torch
    print(f"SUCCESS: Torch imported! Version: {torch.__version__}")
except ImportError as e:
    print(f"FAILURE: ImportError: {e}")
except OSError as e:
    print(f"FAILURE: OSError: {e}")
except Exception as e:
    print(f"FAILURE: Unknown error: {e}")
