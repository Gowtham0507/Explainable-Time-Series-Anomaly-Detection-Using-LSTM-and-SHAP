import argparse
import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import logging
import json
from data_loader import get_dataloaders, AnomalyDataLoader
from model import LSTMAutoencoder

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def set_seed(seed):
    torch.manual_seed(seed)
    # torch.cuda.manual_seed_all(seed) # CUDA not available or trustworthy here
    np.random.seed(seed)
    import random
    random.seed(seed)

def train_channel(config, chan_id, loader, device):
    logger.info(f"Training Model for Channel: {chan_id}")
    
    # Load specific channel data
    # Note: Using loader.load_channel logic but for training split? 
    # The original AnomalyDataLoader.load_channel is designed for inference (returns Test data).
    # We need to construct Train/Val loaders for this specific channel.
    
    # We need to access the internal arrays directly or add a method to get train data for a channel.
    # Let's assume we can get train_data from npy.
    
    try:
        train_npy = os.path.join(loader.train_path, f"{chan_id}.npy")
        if not os.path.exists(train_npy):
            logger.warning(f"Train file for {chan_id} not found.")
            return

        train_data = np.load(train_npy)
        
        # Normalize (fit on train)
        from sklearn.preprocessing import MinMaxScaler
        scaler = MinMaxScaler()
        train_data = scaler.fit_transform(train_data)
        
        # Create Windows
        train_windows, _ = loader._create_windows(train_data)
        
        # Split Train/Val (Simple split for this task, e.g. last 20% for val)
        val_split = int(len(train_windows) * 0.8)
        train_X = train_windows[:val_split]
        val_X = train_windows[val_split:]
        
        if len(train_X) == 0:
             logger.warning(f"Not enough data for {chan_id}")
             return

        # Loaders
        from torch.utils.data import DataLoader, TensorDataset
        train_ds = TensorDataset(torch.tensor(train_X, dtype=torch.float32))
        val_ds = TensorDataset(torch.tensor(val_X, dtype=torch.float32))
        
        train_dl = DataLoader(train_ds, batch_size=config.batch_size, shuffle=True)
        val_dl = DataLoader(val_ds, batch_size=config.batch_size, shuffle=False)
        
        # Model
        input_dim = train_X.shape[2]
        model = LSTMAutoencoder(input_dim=input_dim, hidden_dim=config.hidden_dim, num_layers=config.num_layers)
        model = model.to(device)
        
        optimizer = optim.Adam(model.parameters(), lr=config.lr)
        criterion = nn.MSELoss()
        
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(config.epochs):
            model.train()
            train_loss = 0.0
            for (batch_x,) in train_dl:
                batch_x = batch_x.to(device)
                optimizer.zero_grad()
                recon = model(batch_x)
                loss = criterion(recon, batch_x)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()
            
            train_loss /= max(1, len(train_dl))
            
            # Val
            model.eval()
            val_loss = 0.0
            with torch.no_grad():
                for (batch_x,) in val_dl:
                    batch_x = batch_x.to(device)
                    recon = model(batch_x)
                    loss = criterion(recon, batch_x)
                    val_loss += loss.item()
            val_loss /= max(1, len(val_dl))
            
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                torch.save(model.state_dict(), os.path.join(config.output_dir, f'model_{chan_id}.pth'))
            else:
                patience_counter += 1
                if patience_counter >= config.patience:
                    break
        
        # Save Config for this channel
        chan_config = vars(config).copy()
        chan_config['input_dim'] = input_dim
        with open(os.path.join(config.output_dir, f'config_{chan_id}.json'), 'w') as f:
            json.dump(chan_config, f, indent=4)
            
        logger.info(f"Finished {chan_id} - Best Val Loss: {best_val_loss:.6f}")
        
    except Exception as e:
        logger.error(f"Failed to train {chan_id}: {e}")

def train(config):
    set_seed(config.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    loader = AnomalyDataLoader(config.data_path, seq_len=config.seq_len, seed=config.seed)
    
    # Determine channels to train
    if config.channel:
        channels_to_train = [config.channel]
    else:
        # Train all channels in the specific dataset
        subset = loader.anomalies[loader.anomalies['spacecraft'] == config.dataset]
        channels_to_train = subset['chan_id'].unique().tolist()
        
        # Limit for "Mock" speed if needed? No, user wants full.
        # But for 'Assignment' verification, maybe limit if huge?
        # User said "Do NOT stop until... Model trains successfully", implies full.
        # But we can limit via args if testing.
        if config.limit:
             channels_to_train = channels_to_train[:config.limit]
    
    logger.info(f"Training on {len(channels_to_train)} channels...")
    
    for chan_id in channels_to_train:
        train_channel(config, chan_id, loader, device)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='d:/LSTM/time_series_anomaly_detection/data/raw')
    parser.add_argument('--dataset', type=str, default='SMAP')
    parser.add_argument('--output_dir', type=str, default='d:/LSTM/time_series_anomaly_detection/data/processed')
    parser.add_argument('--epochs', type=int, default=5) 
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--seq_len', type=int, default=100)
    parser.add_argument('--hidden_dim', type=int, default=64)
    parser.add_argument('--num_layers', type=int, default=1)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--patience', type=int, default=3)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--channel', type=str, help="Train only specific channel")
    parser.add_argument('--limit', type=int, help="Limit number of channels to train")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
        
    train(args)
